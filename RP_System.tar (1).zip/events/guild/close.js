const { sleep } = require("../../functions")
    , Panels = require('../../Models/Panels')
    , guildBase = require('../../Models/guildBase')

module.exports = {
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isButton()) return;

        if (interaction.customId.startsWith("close")) {
            let topic = interaction.channel.topic.split("|")
                , panel_id = topic[1].trim()

            let data = await Panels.findOne({ guild: interaction.guild.id, messageId: panel_id })
            if (!data) return interaction.reply({
                content: `**⚠️ - لا استطيع ايجاد معلومات بانل هذه التذكرة ربما تم حذفه**`,
                ephemeral: true
            })

            let db = await guildBase.findOne({ guild: interaction.guild.id })
            if (!db) {
                db = new guildBase({ guild: interaction.guild.id }).save();
            }

            let index = db.claimed.findIndex(c => c.channel == interaction.channel.id)
            if (index == -1) {
                if (data.rolesId.every(role => !interaction.member.roles.cache.has(role)) && !interaction.member.permissions.has("8")) return interaction.reply({
                    content: `**⚠️ - لا يمكنك استخدام هذا الزر**`,
                    ephemeral: true
                })

                interaction.reply({
                    content: `**:white_check_mark: - سيتم اغلاق التذكرة بعد ثواني **`
                }).then(() => {
                    setTimeout(async function () {
                        await interaction.channel.delete().catch(() => 0)
                    }, 5500)
                })
            } else {
                if (db.claimed[index].by != interaction.user.id || !interaction.member.permissions.has("8")) return interaction.reply({
                    content: `**⚠️ - لا يمكنك استخدام هذا الزر**`,
                    ephemeral: true
                })

                db.claimed.splice(index, 1)
                await db.save()

                interaction.reply({
                    content: `**:white_check_mark: - سيتم اغلاق التذكرة بعد ثواني **`
                }).then(() => {
                    setTimeout(async function () {
                        await interaction.channel.delete().catch(() => 0)
                    }, 5500)
                })
            }
        }
    }
};
