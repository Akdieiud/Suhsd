const guildBase = require('../../Models/guildBase')
    , { sleep } = require("../../functions")
    , Panels = require('../../Models/Panels')
    , config = require("../../config/config.json")
    , Discord = require("discord.js")

module.exports = {
    name: `interactionCreate`,
    run: async (interaction, client) => {
        if (!interaction.isButton()) return;

        if (interaction.customId.startsWith("create_")) {
            const panel_id = interaction.customId.split("_")[1]

            let data = await Panels.findOne({ guild: interaction.guild.id, messageId: panel_id })
            if (!data) return interaction.reply({
                content: `**⚠️ - لا استطيع ايجاد معلومات هذا البانل ربما تم حذفه**`,
                ephemeral: true
            })

            let count = data.count.toString().padStart(4, "0")
                , name = `${data.start || "ticket"}-${count}`

            await interaction.guild.channels.create(`${name}`, {
                type: 'GUILD_TEXT',
                parent: data.categoryId || null,
                permissionOverwrites: [
                    {
                        id: interaction.guild.id,
                        deny: [Discord.Permissions.FLAGS.VIEW_CHANNEL],
                        allow: [Discord.Permissions.FLAGS.SEND_MESSAGES, Discord.Permissions.FLAGS.READ_MESSAGE_HISTORY, Discord.Permissions.FLAGS.ATTACH_FILES],
                    },
                    {
                        id: interaction.user.id,
                        allow: [Discord.Permissions.FLAGS.VIEW_CHANNEL],
                    },
                ],
                topic: `${interaction.user.id} | ${panel_id}`
            }).then(async ch => {
                await interaction.reply({ content: `:white_check_mark: Ticket Created! ${ch}`, ephemeral: true })

                data.rolesId.forEach(async role => {
                    let check = interaction.guild.roles.cache.get(role)
                    if (!check) return;

                    sleep(1000)
                    await ch.permissionOverwrites.edit(role, { VIEW_CHANNEL: true });
                })

                data.count = data.count + 1
                await data.save();

                let msg = ""
                data.ticket_embed_message ? msg = data.ticket_embed_message
                    .replaceAll("[user]", interaction.user)
                    .replaceAll("[guild]", interaction.guild.name)
                    .replaceAll("[ticket]", ch.name) : msg = `Welcome, ${interaction.user}\nWait the support`;

                let msg2 = ""
                data.ticketMessage ? msg2 = data.ticketMessage
                    .replaceAll("[user]", interaction.user)
                    .replaceAll("[guild]", interaction.guild.name)
                    .replaceAll("[ticket]", ch.name) : msg2 = `Welcome, ${interaction.user}`;

                let embed = new Discord.MessageEmbed()
                    .setColor("YELLOW")
                    .setDescription(`${msg}`)
                    .setTimestamp()
                    .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() });

                let row = new Discord.MessageActionRow()
                    .addComponents(
                        new Discord.MessageButton()
                            .setCustomId("close")
                            .setStyle("DANGER")
                            .setLabel("قفل"),

                        new Discord.MessageButton()
                            .setCustomId("claim")
                            .setStyle("SUCCESS")
                            .setLabel("استلام")
                    )

                await ch.send({ content: `${msg2} ${data.rolesId.length > 0 ? `| ${data.rolesId.map(role => `<@&${role}>`).join(" ")}` : ""}`, embeds: [embed], components: [row] })
            })
        }
    }
};
