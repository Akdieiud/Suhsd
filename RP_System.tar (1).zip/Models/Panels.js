const { Schema, model } = require('mongoose')

const Database = new Schema({
    guild: String,
    messageId: String,
    channelId: String,
    count: { type: Number, default: 1 },
    start: String,
    categoryId: String,
    tickets_limit: { type: Number, default: 1 },
    ticket_embed_message: String,
    ticketMessage: String,
    rolesId: Array

})

module.exports = model("Panels", Database)