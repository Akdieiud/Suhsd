const guildBase = require('../../Models/guildBase'), ms = require("ms")

module.exports = {
  name: `add-new-reason`,
  description: "لإضافة عقوبة جديدة",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
        name: "name",
        description: "اسم العقوبة",
        required: true,
        type: "STRING"
    },
    {
        name: "time",
        description: "وقت العقوبة",
        type: "STRING",
        required: true
    },
    {
        name: "role",
        description: "الرتبة اللى هتجيه بعد اما يتعاقب",
        type: "ROLE",
        required: true
    }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "add-new-reason") {
        let name = interaction.options.getString("name"),
        time = interaction.options.getString("time"),
        role = interaction.options.getRole("role");

        if(!ms(time)) return interaction.reply({ content: `تأكد من صحة الوقت الذي تريد إضافته`, ephemeral: true })

        let db = await guildBase.findOne({ guild: interaction.guild.id })
        if(!db) {
            db = new guildBase({ guild: interaction.guild.id })
            await db.save()
        }

        let index = db.reasons.findIndex(c => c.name.toLowerCase() == name.toLowerCase())
        if(index != -1) return interaction.reply({ 
            content: `تم إضافة هذه العقوبة من قبل`,
            ephemeral: true
        })

        if(db.reasons.length >= 25) return interaction.reply({ 
            content: `لقد وصلت للحد الاقصى من العقوبات **__25__**`,
            ephemeral: true
        }) 

        db.reasons.push({ name: name, time: ms(time), role: role.id })
        await db.save()
  
        await interaction.reply({ content: `:white_check_mark: تم إضافة عقوبة جديدة بعنوان \`${name}\``, ephemeral: true })
    }
  }
};
