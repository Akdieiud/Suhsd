const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `set-password-role`,
  description: "لتعين رتبة المسؤولين عن تعين كلمة السر",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
      name: "role",
      description: "ارفق الرول الذي تريد تعينها مسؤولين كلمات السر",
      type: "ROLE",
      required: true
    }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "set-password-role") {
        let role = interaction.options.getRole("role")

        let db = await guildBase.findOne({ guild: interaction.guild.id })
        if(!db) {
            db = new guildBase({ guild: interaction.guild.id })
            await db.save()
        }

        db.password_admin = role.id
        await db.save()
  
        await interaction.reply({ content: `:white_check_mark: تم تعين الرتبة المسؤولة عن كلمات السر الى ${role}`, ephemeral: true })
    }
  }
};
