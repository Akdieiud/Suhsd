const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `auto-line-channels`,
  description: "لتعين رومات الخط التلقائي",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
        name: "add",
        type: 1,
        description: "لإضافة رومات خط تلقائي",
        options: [
            {
                name: "channel",
                type: "CHANNEL",
                description: "منشن الروم الذي تريد اضافتها للخط التلقائي",
                required: true,
                channel_types: ["0"]

            }
        ]
    },
    {
        name: "remove",
        type: 1,
        description: "لإزالة روم من الخط التلقائي",
        options: [
            {
                name: "channel",
                type: "CHANNEL",
                description: "منشن الروم الذي تريد ازالته من الخط التلقائي",
                required: true,
                channel_types: ["0"]

            }
        ]
    }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "auto-line-channels") {
        let channel = interaction.options.getChannel("channel")
        , subcommand = interaction.options._subcommand

        let db = await guildBase.findOne({ guild: interaction.guild.id })
        if(!db) {
            db = new guildBase({ guild: interaction.guild.id })
            await db.save()
        }

        if(subcommand == "add") {
            if(db.auto_line["channels"].includes(channel.id)) return interaction.reply({
                content: `تم اضافة هذا الروم من قبل`,
                ephemeral: true
            })

            db.auto_line["channels"].push(channel.id)
            await db.save();
        } else if(subcommand == "remove") {
            let index = db.auto_line["channels"].findIndex(c => c == channel.id)
            if(index == -1) return interaction.reply({
                content: `لم يتم اضافة هذا الروم من قبل`,
                ephemeral: true
            })

            db.auto_line["channels"].splice(index, 1)
            await db.save()
        }
  
        await interaction.reply({ 
            content: `:white_check_mark: تم ${subcommand == "add" ? "إضافة" : "إزالة"} الروم ${channel} ${subcommand == "add" ? "الى" : "من"} رومات الخط التلقائي`, 
            ephemeral: true 
        })
    }
  }
};
