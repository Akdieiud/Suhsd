const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `set-bank-chat`,
  description: "لتعين روم البنك",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
        name: "channel",
        type: "CHANNEL",
        description: `اختر الروم الذي تريد تعينه للبنك`,
        required: true,
        channel_types: ["0"]
    }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "set-bank-chat") {
      let channel = interaction.options.getChannel("channel")

      let db = await guildBase.findOne({ guild: interaction.guild.id })
      if(!db) {
        db = new guildBase({ guild: interaction.guild.id })
        await db.save()
      }

      db.channels["bank"] = channel.id
      await db.save()

      interaction.reply({ content: `:white_check_mark: تم تعين روم البنك الى ${channel}`, ephemeral: true })
    }
  }
};
