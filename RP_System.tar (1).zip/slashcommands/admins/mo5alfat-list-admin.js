const guildBase = require('../../Models/guildBase')

module.exports = {
  name: `mo5alfa-list-admin`,
  description: "لتعين الرول الذي يمكنها الاطلاع على المخالفات",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
        name: "role",
        description: "ارفق الرول الذي تريد تعينها",
        type: "ROLE",
        required: true
      }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "mo5alfa-list-admin") {
      let role = interaction.options.getRole("role")

      let db = await guildBase.findOne({ guild: interaction.guild.id })
      if(!db) {
        db = new guildBase({ guild: interaction.guild.id })
        await db.save()
      }

      db.mo_listadmin = role.id
      await db.save()
      
      await interaction.reply({ content: `:white_check_mark: تم تعين الرتبة المسؤولة عن ليست المخالفات الى ${role}`, ephemeral: true })

    }
  }
};
