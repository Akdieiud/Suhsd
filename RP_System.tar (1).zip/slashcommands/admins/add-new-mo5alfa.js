const guildBase = require('../../Models/guildBase')

module.exports = {
  name: `add-new-mo5alfa`,
  description: "لإضافة مخالفة شرطة جديدة",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
      name: "name",
      description: "أرفق اسم المخالفة",
      required: true,
      type: "STRING"
    },
    {
      name: "price",
      description: "ارفق سعر هذه المخالفة",
      type: "NUMBER",
      required: true,
      min_value: 1
    }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "add-new-mo5alfa") {
      let name = interaction.options.getString("name"),
      price = interaction.options.getNumber("price");

      let db = await guildBase.findOne({ guild: interaction.guild.id })
      if(!db) {
        db = new guildBase({ guild: interaction.guild.id })
        await db.save()
      }

      let index = db.mo5alfat.findIndex(c => c.name.toLowerCase() == name.toLowerCase())
      if(index != -1) return interaction.reply({ 
        content: `تم إضافة هذه المخالفة من قبل`,
        ephemeral: true
      })

      if(db.mo5alfat.length >= 25) return interaction.reply({ 
        content: `لقد وصلت للحد الاقصى من مخالفات الشرطة **__25__**`,
        ephemeral: true
      }) 

      db.mo5alfat.push({ name: name, price: parseInt(price) })
      await db.save()
      
      await interaction.reply({ 
        content: `:white_check_mark: تم إضافة مخالفة جديدة بعنوان \`${name}\``, 
        ephemeral: true 
      })
    }
  }
};
