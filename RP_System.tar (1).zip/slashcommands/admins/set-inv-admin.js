const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `set-inv-role`,
  description: "لتعين رتبة المسؤولين عن اوامر الحقيبة والبنك",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
      name: "role",
      description: "ارفق الرول الذي تريد تعينها مسؤولين الحقيبة والبنك",
      type: "ROLE",
      required: true
    }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "set-inv-role") {
        let role = interaction.options.getRole("role")

        let db = await guildBase.findOne({ guild: interaction.guild.id })
        if(!db) {
            db = new guildBase({ guild: interaction.guild.id })
            await db.save()
        }

        db.invbank = role.id
        await db.save()
  
        await interaction.reply({ content: `:white_check_mark: تم تعين الرتبة المسؤولة عن الحقيبة والبنك الى ${role}`, ephemeral: true })
    }
  }
};
