const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `set-tf3el-log`,
  description: "لتعين روم اللوج للتفعيلات",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
      name: "channel",
      description: "ارفق الروم الذي تريد تعينها للوج",
      type: "CHANNEL",
      required: true,
      channel_types: ["0"]
    }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "set-tf3el-log") {
        let channel = interaction.options.getChannel("channel")

        let db = await guildBase.findOne({ guild: interaction.guild.id })
        if(!db) {
            db = new guildBase({ guild: interaction.guild.id })
            await db.save()
        }

        db.tf3el["log"] = channel.id
        await db.save()
  
        await interaction.reply({ content: `:white_check_mark: تم تعين روم لوج التفعيلات الى ${channel}`, ephemeral: true })
    }
  }
};
