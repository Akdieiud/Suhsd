const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `set-points-staff`,
  description: "لتعين المسؤولين عن اوامر النقاط",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
      name: "role",
      description: "ارفق الرول الذي تريد تعينها مسؤولين الادارة",
      type: "ROLE",
      required: true
    }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "set-points-staff") {
        let role = interaction.options.getRole("role")

        let db = await guildBase.findOne({ guild: interaction.guild.id })
        if(!db) {
            db = new guildBase({ guild: interaction.guild.id })
            await db.save()
        }

        db.staff_points = role.id
        await db.save()
  
        await interaction.reply({ content: `:white_check_mark: تم تعين الرتبة المسؤولة عن النقاط الى ${role}`, ephemeral: true })
    }
  }
};
