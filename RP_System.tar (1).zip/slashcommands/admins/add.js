const guildBase = require('../../Models/guildBase'), ms = require("ms")
    , Panels = require('../../Models/Panels')
module.exports = {
    name: `add`,
    description: "لإضافة عضو داخل التذكرة",
    default_member_permissions: "0x0000000000000008",
    options: [
        {
            name: "target",
            description: "أرفق الشخص الذي تريد اضافته للتذكرة",
            required: true,
            type: "USER"
        }
    ],
    run: async (client, interaction, Discord) => {
        if (interaction.commandName == "add") {
            let target = interaction.options.getUser("target")
                , topic = interaction.channel.topic?.split("|")
            if (!topic) return interaction.reply({
                ephemeral: true,
                content: `يجب عليك استخدام هذا الامر داخل تذكرة`

            })

            let panel_id = topic[1]?.trim()
            if (!panel_id) return interaction.reply({
                ephemeral: true,
                content: `يجب عليك استخدام هذا الامر داخل تذكرة`
            })

            let db = await Panels.findOne({ guild: interaction.guild.id, messageId: panel_id })
            if (!db) return interaction.reply({
                content: `لا استطيع ايجاد بانل هذه التذكرة ربما تم حذفه`,
                ephemeral: true

            })

            if (db.rolesId.every(role => !interaction.member.roles.cache.has(role)) && !interaction.member.permissions.has("8")) return interaction.reply({
                content: `لا يمكنك استخدام هذا الزر`,
                ephemeral: true
            })

            await interaction.channel.permissionOverwrites.edit(target.id, { VIEW_CHANNEL: true });

            await interaction.reply({
                content: `:white_check_mark: تم إضافة ${target} داخل التذكرة \`${interaction.channel.name}\``
            })

        }
    }
};
