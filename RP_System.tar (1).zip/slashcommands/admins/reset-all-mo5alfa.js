const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `reset-all-mo5alfat`,
  description: "لحذف جميع مخالفات الشرطة",
  default_member_permissions: "0x0000000000000008",
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "reset-all-mo5alfat") {
        let db = await guildBase.findOne({ guild: interaction.guild.id })
        if(!db) {
            db = new guildBase({ guild: interaction.guild.id })
            await db.save()
        }

        db.mo5alfat = []
        await db.save()
  
        await interaction.reply({ content: `:white_check_mark: تم حذف جميع مخالفات الشرطة`, ephemeral: true })
    }
  }
};
