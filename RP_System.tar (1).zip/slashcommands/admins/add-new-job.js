const guildBase = require('../../Models/guildBase')

module.exports = {
  name: `add-new-job`,
  description: "لإضافة وظيفة جديدة",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
      name: "name",
      description: "أرفق اسم الوظيفة",
      required: true,
      type: "STRING"
    },
    {
      name: "role",
      description: "ارفق رول هذه الوظيفة",
      type: "ROLE",
      required: true,
      min_value: 1
    }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "add-new-job") {
      let name = interaction.options.getString("name"),
      role = interaction.options.getRole("role");

      let db = await guildBase.findOne({ guild: interaction.guild.id })
      if(!db) {
        db = new guildBase({ guild: interaction.guild.id })
        await db.save()
      }

      let index = db.jobs.findIndex(c => c.name.toLowerCase() == name.toLowerCase())
      if(index != -1) return interaction.reply({ 
        content: `تم إضافة هذه الوظيفة من قبل`,
        ephemeral: true
      })

      if(db.jobs.length >= 25) return interaction.reply({ 
        content: `لقد وصلت للحد الاقصى من الوظايف **__25__**`,
        ephemeral: true
      }) 

      db.jobs.push({ name: name, role: role.id })
      await db.save()
      
      await interaction.reply({ 
        content: `:white_check_mark: تم إضافة وظيفة جديدة بعنوان \`${name}\``, 
        ephemeral: true 
      })
    }
  }
};
