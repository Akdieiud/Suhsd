const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `set-blacklist-role`,
  description: "لتعين رتبة المسؤولين عن اوامر البلاك ليست",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
      name: "role",
      description: "ارفق الرول الذي تريد تعينها مسؤولين البلاك ليست",
      type: "ROLE",
      required: true
    }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "set-blacklist-role") {
        let role = interaction.options.getRole("role")

        let db = await guildBase.findOne({ guild: interaction.guild.id })
        if(!db) {
            db = new guildBase({ guild: interaction.guild.id })
            await db.save()
        }

        db.blacklist = role.id
        await db.save()
  
        await interaction.reply({ content: `:white_check_mark: تم تعين الرتبة المسؤولة عن اوامر البلاك ليست الى ${role}`, ephemeral: true })
    }
  }
};
