const guildBase = require('../../Models/guildBase')
    , Panels = require('../../Models/Panels')

module.exports = {
    name: `panel`,
    description: "create/edit",
    type: 1,
    default_member_permissions: "0x0000000000000008",
    options: [
        {
            name: "create",
            description: "لإنشاء بانل تذاكر جديدة",
            type: 1,
            options: [
                {
                    name: "title",
                    description: 'أختر العنوان الذي تريد تعينه للامبد',
                    required: true,
                    type: "STRING"
                },
                {
                    name: 'description',
                    description: 'أختر الوصف الذي تريد تعينه للامبد',
                    required: true,
                    type: "STRING"
                },
                {
                    name: 'support_role',
                    description: 'أختر رتبة الدعم الفني الذي تريد تعينها للبانل',
                    required: false,
                    type: "ROLE"
                },
                {
                    name: 'ticket_open_message',
                    description: 'أكتب رسالة التكت الذي تريد تعينها داخل التكت',
                    required: false,
                    type: "STRING"
                },
                {
                    name: 'ticket_embed_message',
                    description: 'أختر رسالة التكت الذي تريد تعينها داخل امبد التكت',
                    required: false,
                    type: "STRING"
                },
                {
                    name: 'category',
                    description: 'أختر الكاتوجري اللي هينشأ فيه التكتات',
                    type: 'CHANNEL',
                    channel_type: [4],
                    required: false
                },
                {
                    name: 'image',
                    description: 'أرفق صورة الانفو الذي تريد تعينها للبانل',
                    type: 'ATTACHMENT',
                    required: false
                },
                {
                    name: 'tickets_limit',
                    description: 'أكتب الحد الاقصى للتكتات الذي تريد تعينه',
                    type: 'NUMBER',
                    min_value: 1,
                    required: false
                },
                {
                    name: 'button_name',
                    description: 'أكتب اسم الزر الذي تريد تسميته',
                    type: 'STRING',
                    required: false
                },
                {
                    name: 'button_color',
                    description: 'أختر لون الزر الذي تريد تعينه',
                    type: 'STRING',
                    choices: [
                        { name: 'Blurple', value: 'PRIMARY' },
                        { name: 'Gray', value: 'SECONDARY' },
                        { name: 'Green', value: 'SUCCESS' },
                        { name: 'Red', value: 'DANGER' }
                    ],
                    required: false
                },
                {
                    name: 'channel_start',
                    description: 'أكتب باءدة اسماء التكتات',
                    type: "STRING",
                    required: false
                }
            ]
        },
        {
            name: "edit",
            description: "للتعديل على بانل قديم",
            type: 1,
            options: [
                {
                    name: 'message_id',
                    description: 'أرفق ايدي رسالة البانل',
                    required: true,
                    type: "STRING"
                },
                {
                    name: 'title',
                    description: 'أكتب العنوان الجديد الذي تريد تعينه',
                    required: false,
                    type: "STRING"
                },
                {
                    name: 'description',
                    description: 'أكتب الوصف الجديد الذي تريد تعينه',
                    required: false,
                    type: "STRING"
                },
                {
                    name: 'support_role',
                    description: 'أرفق الرول الجديدة الذي تريد اضافتها',
                    required: false,
                    type: "ROLE"
                },
                {
                    name: 'ticket_open_message',
                    description: 'أكتب رسالة التذكرة الذي تريد تعديلها',
                    required: false,
                    type: "STRING"
                },
                {
                    name: 'ticket_embed_message',
                    description: 'أكتب رسالة التذكرة داخل الامبد الذي تريد تعديلها',
                    required: false,
                    type: "STRING"
                },
                {
                    name: 'category',
                    description: 'أختر كاتوجري التكتات الذي تريد تعينه',
                    type: 'CHANNEL',
                    channel_type: [4],
                    required: false
                },
                {
                    name: 'image',
                    description: 'أرفق صورة البانل الذي تريد تعينها',
                    type: 'ATTACHMENT',
                    required: false
                },
                {
                    name: 'tickets_limit',
                    description: 'أكتب حد اقصى التكتات الذي تريد تعينه',
                    type: 'NUMBER',
                    required: false
                },
                {
                    name: 'button_name',
                    description: 'أكتب اسم الزر الجديد الذي تريد تعينه',
                    type: 'STRING',
                    required: false
                },
                {
                    name: 'button_color',
                    description: 'أختر لون الزر الجديد الذي تريد تعينه',
                    type: 'STRING',
                    choices: [
                        { name: 'Blurple', value: 'PRIMARY' },
                        { name: 'Gray', value: 'SECONDARY' },
                        { name: 'Green', value: 'SUCCESS' },
                        { name: 'Red', value: 'DANGER' }
                    ],
                    required: false
                },
                {
                    name: 'channel_start',
                    description: 'أكتب باءدة اسماء التكتات الجديدة الذي تريد تعينها',
                    type: "STRING",
                    required: false
                }
            ]
        },
        {
            name: "delete",
            description: "لحذف بانل قديم",
            type: 1,
            options: [
                {
                    name: 'message_id',
                    description: 'أرفق ايدي رسالة البانل الذي تريد حذفه',
                    required: true,
                    type: "STRING"
                }
            ]
        }
    ],
    run: async (client, interaction, Discord) => {
        if (interaction.commandName == "panel") {
            let subcommand = interaction.options._subcommand

            if (subcommand == "create") {
                let title = interaction.options.getString('title')
                let description = interaction.options.getString('description')?.replaceAll('//', '\n')
                let support_role = interaction.options.getRole('support_role')
                let ticket_message = interaction.options.getString('ticket_open_message')?.replaceAll('//', '\n')
                let ticket_embed_message = interaction.options.getString('ticket_embed_message')?.replaceAll('//', '\n')
                let category = interaction.options.getChannel('category')
                let tickets_limit = interaction.options.getNumber('tickets_limit')
                let image = interaction.options.getAttachment('image')
                let button_name = interaction.options.getString('button_name')
                let button_color = interaction.options.getString('button_color')
                let channel_start = interaction.options.getString('channel_start')

                let row = new Discord.MessageActionRow()
                    .addComponents(
                        new Discord.MessageButton()
                            .setStyle(button_color ? button_color : "SECONDARY")
                            .setEmoji("📩")
                            .setLabel(button_name ? button_name : "Create ticket")
                            .setCustomId('hamoudi')
                    )

                let embed = new Discord.MessageEmbed()
                    .setColor("YELLOW")
                    .setTitle(`${title}`)
                    .setDescription(`${description}`)

                image ? embed.setImage(image.proxyURL) : 0

                await interaction.channel.send({
                    components: [row],
                    embeds: [embed]
                }).then(async msg => {
                    await row.components[0].setCustomId(`create_${msg.id}`)
                    msg.edit({
                        components: [row]
                    })

                    new Panels({
                        guild: interaction.guild.id,
                        messageId: msg.id,
                        channelId: msg.channel.id,
                        count: 1
                    }).save()

                    let data = await Panels.findOne({ guild: interaction.guild.id, messageId: msg.id })

                    if (ticket_message) {
                        data.ticketMessage = ticket_message
                        await data.save()
                    }

                    if (channel_start) {
                        if (channel_start.length > 20) return interaction.reply({ content: `يجب ان تكون بادءة الرومات اقل من 20 حرف`, ephemeral: true })

                        data.start = channel_start
                        await data.save()
                    }

                    if (ticket_embed_message) {
                        data.ticket_embed_message = ticket_embed_message
                        await data.save()
                    }

                    if (support_role) {
                        data.rolesId.push(support_role.id)
                        await data.save()
                    }

                    if (tickets_limit) {
                        data.tickets_limit = tickets_limit
                        await data.save()
                    }

                    if (category) {
                        data.categoryId = category.id
                        await data.save()
                    }

                    await interaction.reply({ 
                        content: `:white_check_mark: Panel Created!`,
                        ephemeral: true 
                    })
                    
                })
            }

            else if (subcommand == "edit") {
                let panel_id = interaction.options.getString('message_id')

                let data = await Panels.findOne({ guild: interaction.guild.id, messageId: panel_id })
                if (!data) return interaction.reply({
                    content: `لا أستطيع ايجاد بانل بهذا الايدي \`${panel_id}\``,
                    ephemeral: true
                })

                const channel = interaction.guild.channels.cache.get(data.channelId)
                if (!channel) return interaction.reply({
                    content: `لا استطيع ايجاد روم هذا البانل \`${panel_id}\``,
                    ephemeral: true
                })

                const message1 = await channel.messages.fetch(data.messageId)
                if (!message1) return interaction.reply({
                    content: `لا أستطيع ايجاد رسالة هذا البانل \`${panel_id}\``,
                    ephemeral: true
                })

                let title = interaction.options.getString('title')
                let description = interaction.options.getString('description')?.replaceAll('//', '\n')
                let support_role = interaction.options.getRole('support_role')
                let ticket_message = interaction.options.getString('ticket_open_message')?.replaceAll('//', '\n')
                let ticket_embed_message = interaction.options.getString('ticket_embed_message')?.replaceAll('//', '\n')
                let category = interaction.options.getChannel('category')
                let tickets_limit = interaction.options.getNumber('tickets_limit')
                let channel_start = interaction.options.getString('channel_start')

                let image = interaction.options.getAttachment('image')
                let button_name = interaction.options.getString('button_name')
                let button_color = interaction.options.getString('button_color')

                if (!title && !description && !tickets_limit && !channel_start && !ticket_embed_message && !support_role && !ticket_message && !category && !image && !button_name && !button_color) return interaction.reply({
                    content: `يجب عليك تعديل عنصر 1 على الاقل`,
                    ephemeral: true
                })

                if (channel_start && channel_start.length > 20) return interaction.reply({
                    content: `يجب ان تكون بادءة الرومات اقل من 20 حرف`,
                    ephemeral: true
                })

                const old_embed = message1.embeds[0]
                    , old_button = message1.components[0]?.components[0]

                let row = new Discord.MessageActionRow()
                    .addComponents(
                        new Discord.MessageButton()
                            .setStyle(button_color ? button_color : old_button["style"])
                            .setEmoji("📩")
                            .setLabel(button_name ? button_name : old_button["label"])
                            .setCustomId(`create_${data.messageId}`)
                    )

                let embed = new Discord.MessageEmbed()
                    .setColor("YELLOW")
                    .setTitle(`${title ? title : old_embed["title"]}`)
                    .setDescription(`${description ? description : old_embed["description"]}`)

                image ? embed.setImage(image.proxyURL) : embed.setImage(old_embed["image"]?.proxyURL)

                await message1.edit({
                    components: [row],
                    embeds: [embed]
                }).then(async () => {
                    await interaction.reply({
                        content: `:white_check_mark: Panel Edited!`,
                        ephemeral: true
                    })

                    if (support_role) {
                        if (data.rolesId.includes(support_role.id)) {
                            var index = data.rolesId.indexOf(support_role.id);
                            if (index !== -1) {
                                data.rolesId.splice(index, 1);
                            }
                        } else {
                            data.rolesId.push(support_role.id)
                        }

                        await data.save()
                    }

                    if (channel_start) {
                        data.start = channel_start
                        await data.save()
                    }

                    if (ticket_message) {
                        data.ticketMessage = ticket_message
                        await data.save()
                    }

                    if (tickets_limit) {
                        data.tickets_limit = tickets_limit
                        await data.save()
                    }

                    if (ticket_embed_message) {
                        data.ticket_embed_message = ticket_embed_message
                        await data.save()
                    }

                    if (category) {
                        data.categoryId = category.id
                        await data.save()
                    }
                })
            }

            else if (subcommand == "delete") {
                let panel_id = interaction.options.getString('message_id')

                let data = await Panels.findOne({ guild: interaction.guild.id, messageId: panel_id })
                if (!data) return interaction.reply({
                    content: `لا أستطيع ايجاد بانل بهذا الايدي \`${panel_id}\``,
                    ephemeral: true
                })

                const channel = interaction.guild.channels.cache.get(data.channelId)
                if (!channel) return interaction.reply({
                    content: `لا استطيع ايجاد روم هذا البانل \`${panel_id}\``,
                    ephemeral: true
                })

                const message1 = await channel.messages.fetch(data.messageId)
                if (!message1) return interaction.reply({
                    content: `لا أستطيع ايجاد رسالة هذا البانل \`${panel_id}\``,
                    ephemeral: true
                })

                await Panels.deleteMany({ guild: interaction.guild.id, messageId: panel_id })

                await message1.delete();

                await interaction.reply({ content: ":white_check_mark: Panel Deleted!" })
            }
        }
    }
};
