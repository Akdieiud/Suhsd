const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `delete-mo5alfa`,
  description: "لحذف مخالفة من مخالفات الشرطة",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
        name: "name",
        description: "أرفق اسم المخالفة الذي تريد حذفها",
        required: true,
        type: "STRING"
    }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "delete-mo5alfa") {
        let name = interaction.options.getString("name");

        let db = await guildBase.findOne({ guild: interaction.guild.id })
        if(!db) {
            db = new guildBase({ guild: interaction.guild.id })
            await db.save()
        }

        let index = db.mo5alfat.findIndex(c => c.name.toLowerCase() == name.toLowerCase())
        if(index == -1) return interaction.reply({ content: `لا أستطيع ايجاد هذه المخالفة داخل المخالفات`, ephemeral: true })

        db.mo5alfat.splice(index, 1)
        await db.save()
  
        await interaction.reply({ content: `:white_check_mark: تم حذف مخالفة من مخالفات الشرطة بعنوان \`${name}\``, ephemeral: true })
    }
  }
};
