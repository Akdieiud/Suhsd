const guildBase = require('../../Models/guildBase')
module.exports = {
  name: `remove-tf3el-roles`,
  description: "لإزالة رولات تمت اضافتها من قبل",
  default_member_permissions: "0x0000000000000008",
  options: [
    {
        name: "action",
        description: "اختر نوع الرول",
        required: true,
        type: "STRING",
        choices: [
            { name: "Add", value: "add" },
            { name: "Remove", value: "remove" }
        ]
    },
    {
      name: "role",
      description: "ارفق الرول الذي تريد تعينها",
      type: "ROLE",
      required: true
    }
  ],
  run: async (client, interaction, Discord) => {
    if(interaction.commandName == "remove-tf3el-roles") {
        let action = interaction.options.getString("action"),
        role = interaction.options.getRole("role");

        let db = await guildBase.findOne({ guild: interaction.guild.id })
        if(!db) {
            db = new guildBase({ guild: interaction.guild.id })
            await db.save()
        }

        let index = db.tf3el[action == "add" ? "add_role" : "remove_role"].findIndex(d => d == role.id)
        if(index == -1) return interaction.reply({
            content: `لم يتم اضافة هذه الرول من قبل`,
            ephemeral: true
        })

        db.tf3el[action == "add" ? "add_role" : "remove_role"].splice(index, 1)
        await db.save()
  
        await interaction.reply({ content: `:white_check_mark: تم ازالة الرول ${role} من رولات التفعيل`, ephemeral: true })
    }
  }
};