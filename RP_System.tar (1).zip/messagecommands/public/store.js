const guildBase = require('../../Models/guildBase')
module.exports = {
    name: `store`,
    run: async (client, message, args, Discord) => {
        let data = await guildBase.findOne({ guild: message.guild.id })
        if (!data) {
            data = new guildBase({ guild: message.guild.id })
            await data.save()
        }

        const allinvs = [], max = 10, inv = [...data.store];

        if (inv.length <= 0) return message.reply({
            content: `**⚠️ - لا يوجد منتجات حتى الان لعرضها داخل المتجر**`
        })

        while (inv.length) {
            allinvs.push(inv.splice(0, max));
        }

        function generateEmbed(page) {
            const embed = new Discord.MessageEmbed()
                .setTitle(`مجموع الاغراض داخل الصفحة ( ${allinvs[page].length} )`)
                .setColor("BLURPLE")
                .setTimestamp()
                .setThumbnail(message.guild.iconURL({ dynamic: true }))
                .setFooter({ text: `مجموع الاغراض ( ${data.store.length} )`, iconURL: message.author.avatarURL({ dynamic: true }) })
                .setDescription(allinvs[page].map(d => `- ${d.name} : ${d.price}$`).join("\n"));

            return embed;
        }

        var currentPage = 0;
        let row2 = new Discord.MessageActionRow().addComponents(
            new Discord.MessageButton()
                .setCustomId(`back`)
                .setLabel("رجوع")
                .setStyle("PRIMARY")
                .setDisabled(currentPage == 0),

            new Discord.MessageButton()
                .setCustomId(`next`)
                .setLabel("التالي")
                .setStyle("PRIMARY")
                .setDisabled(data.store.length <= 10)
        )

        let msg2 = await message.reply({
            content: null,
            embeds: [generateEmbed(currentPage)],
            components: [row2]
        });

        const collector2 = msg2.createMessageComponentCollector({ componentType: 'BUTTON', time: 120000 });
        collector2.on('collect', async (i2) => {
            if (i2.user.id != message.author.id) return;

            await i2.deferUpdate();

            if (i2.customId === 'back') {
                currentPage -= 1;

                if (currentPage < 0) currentPage = allinvs.length - 1;
            } else if (i2.customId === 'next') {
                currentPage += 1;

                if (currentPage === allinvs.length) currentPage = 0;
            }

            await row2.components[0].setDisabled(currentPage === 0);
            await row2.components[1].setDisabled(currentPage === allinvs.length - 1);

            await msg2.edit({
                embeds: [generateEmbed(currentPage)],
                components: [row2]
            });
        });

        collector2.on('end', collected => {
            if (collected.size > 0) return;

            msg2.delete();
        });
    }
};
