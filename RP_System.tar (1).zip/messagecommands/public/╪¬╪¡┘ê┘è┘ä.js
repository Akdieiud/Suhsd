const userBase = require('../../Models/userBase')
    , guildBase = require('../../Models/guildBase')

module.exports = {
    name: `تحويل`,
    run: async (client, message, args, Discord) => {

        let db = await guildBase.findOne({ guild: message.guild.id })
        if (!db) {
            db = new guildBase({ guild: message.guild.id })
            await db.save();
        }

        let user_roles = message.member.roles.cache.map(c => c.id)
            , required_roles = db.tf3el.add_role

        if ((required_roles.every(val => user_roles.includes(val.toLowerCase())) && user_roles.length >= required_roles.length) == false) return message.reply({
            content: `**⚠️ - عذراً ، لا يمكنك استخدام هذا الامر لانك غير مُفعل**`,
            components: []
        })

        let user = message.mentions.members.first()
        if (!user) return message.reply({
            content: `**⚠️ - يجب عليك تحديد الشخص الذي تريد التحويل له**`
        })

        let amount = args[1]
        if (!amount || isNaN(amount)) return message.reply({
            content: `**⚠️ - يجب عليك تحديد الكمية الذي تريد تحويلها**`
        })

        if (user.user.bot || user.user.id == message.author.id) return message.reply({
            content: `**⚠️ - عذراً ، لكنك لا تستطيع التحويل الى ${user}**`
        })

        let user_roles2 = user.roles.cache.map(c => c.id)
            , required_roles2 = db.tf3el.add_role

        if ((required_roles2.every(val => user_roles2.includes(val.toLowerCase())) && user_roles2.length >= required_roles2.length) == false) return message.reply({
            content: `**⚠️ - عذراً ، لا يمكنك التحويل لهذا الشخص لانه غير مُفعل**`,
            components: []
        })

        let row = new Discord.MessageActionRow().addComponents(
            new Discord.MessageButton()
                .setCustomId(`transfer_${message.author.id}_1`)
                .setLabel("الشخصية الاولى")
                .setStyle("SECONDARY"),

            new Discord.MessageButton()
                .setCustomId(`transfer_${message.author.id}_2`)
                .setLabel("الشخصية الثانية")
                .setStyle("SECONDARY")
        )

        let msg = await message.reply({
            content: `**قم بإختيار الشخصية الذي تريد سحب الفلوس منها**`,
            components: [row]
        })

        const collector = msg.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
        collector.on('collect', async i => {
            if (i.user.id != message.author.id) return i.reply({
                content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
                ephemeral: true
            })

            let row2 = new Discord.MessageActionRow().addComponents(
                new Discord.MessageButton()
                    .setCustomId(`transfer_${message.author.id}_1`)
                    .setLabel("الشخصية الاولى")
                    .setStyle("SECONDARY"),

                new Discord.MessageButton()
                    .setCustomId(`transfer_${message.author.id}_2`)
                    .setLabel("الشخصية الثانية")
                    .setStyle("SECONDARY")
            )

            await msg.delete();

            let msg2 = await message.reply({
                content: `**قم بإختيار الشخصية الذي تريد التحويل عليها**`,
                components: [row2]
            })

            const collector2 = msg2.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
            collector2.on('collect', async hamoudi => {
                if (hamoudi.user.id != message.author.id) return hamoudi.reply({
                    content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
                    ephemeral: true
                })
                let main_author = message.author
                    , second_author = user
                    , total_amount = parseInt(amount)

                let main_data = await userBase.findOne({ guild: message.guild.id, user: main_author.id })
                if (!main_data) {
                    main_data = new userBase({ guild: message.guild.id, user: main_author.id })
                    await main_data.save()
                }

                let second_data = await userBase.findOne({ guild: message.guild.id, user: second_author.id })
                if (!second_data) {
                    second_data = new userBase({ guild: message.guild.id, user: second_author.id })
                    await second_data.save()
                }

                const password = main_data.password
                if (!password) return msg2.edit({
                    content: `**⚠️ - عذرا ، لكنك لا تملك كلمة سر خاصة تواصل مع الدعم الفني**`,
                    components: []
                })

                i.customId.endsWith("1") ? main_data = main_data.c1 : main_data = main_data.c2
                hamoudi.customId.endsWith("1") ? second_data = second_data.c1 : second_data = second_data.c2

                if (parseInt(main_data.bank) < total_amount) return msg2.edit({
                    content: `**⚠️ - عذرا ، ولكن رصيد شخصيتك ${i.customId.endsWith("1") ? "الاولى" : "الثانية"} أقل من المبلغ الذي تريد تحويله**`,
                    components: []
                })

                let msg3 = await msg2.edit({ components: [], content: `**⏲️ - لديك 15 ثانية أرفق كلمة السر الخاصة بحسابك البنكي**` })
                const collector3 = msg3.channel.createMessageCollector({ time: 15000 });
                collector3.on('collect', async m => {
                    if (m.author.id != message.author.id) return;

                    if (m.content != password) {
                        msg2.edit({
                            components: [],
                            content: `**❌ - عذراً ولكن كلمة السر التي قمت بأرفاقها غير صحيحة حاول مرة آخرى**`
                        })

                        return collector3.stop();
                    }

                    await userBase.updateOne({ guild: message.guild.id, user: main_author.id },
                        { $set: { [`${i.customId.endsWith("1") ? "c1" : "c2"}.bank`]: parseInt(main_data.bank) - total_amount } }
                    );

                    await userBase.updateOne({ guild: message.guild.id, user: second_author.id },
                        { $set: { [`${hamoudi.customId.endsWith("1") ? "c1" : "c2"}.bank`]: parseInt(second_data.bank) + total_amount } }
                    );

                    m.delete().catch(() => 0)

                    let embed = new Discord.MessageEmbed()
                        .setColor("YELLOW")
                        .setThumbnail(message.guild.iconURL())
                        .setTimestamp()
                        .setAuthor({ name: "✅ تم التحويل بنجاح", iconURL: message.guild.iconURL() })
                        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
                        .setDescription(`**| للمواطن : ${user}

| من قبل :  ${message.author}

| المبلغ : __${total_amount}__

| تم تحويلها من الشخصية : ${i.customId.endsWith("1") ? "الاولى" : "الثانية"}

| تم استلامها من الشخصية : ${hamoudi.customId.endsWith("1") ? "الاولى" : "الثانية"}

تم تأكيد الحوالة من قبل وزارة المالية - 🏦**`)

                    await msg3.edit({
                        content: null,
                        embeds: [embed],
                        components: [],
                    })

                    return collector3.stop();
                });
            });

            collector2.on('end', collected => {
                if (collected.size > 0) return;

                msg2.delete();
            });
        });

        collector.on('end', collected => {
            if (collected.size > 0) return;

            msg.delete();
        });
    }
};
