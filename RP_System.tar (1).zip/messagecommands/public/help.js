const { prefix } = require("../../config/config");

module.exports = {
  name: `help`,
  run: async (client, message, args, Discord) => {
    if(!message.member.permissions.has("8")) return;

    let row = new Discord.MessageActionRow()
    .addComponents(
      new Discord.MessageSelectMenu()
      .setCustomId(`help_menu`)
      .setMaxValues(1)
      .setPlaceholder("Nothing Selected!")
      .addOptions(
        { label: `Staff Commands`, value: `staff`, description: `أوامر الادارة`, emoji: "<:pp572:1136320925491540059>" },
        { label: `Set Commands`, value: `set`, description: "أوامر التعين", emoji: "<:pp256:1136320546716532837>" },
        { label: `Public Commands`, value: `public`, description: `الأوامر عامة`, emoji: "<:emoji_116:1086253295380746250>" },
        { label: `Moderation Commands`, value: `mod`, description: `أوامر المسؤولين`, emoji: "<:pp572:1136320925491540059>" }
       )
    )

    let embed = new Discord.MessageEmbed()
    .setAuthor({ name: "Help Menu", iconURL: message.guild.iconURL({ dynamic: true }) })
    .setColor("YELLOW")
    .setTimestamp()
    .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL({ dynamic: true }) })
    .setDescription(`قم بإختيار نوع القسم الذي تريده`)
    .setThumbnail(message.guild.iconURL({ dynamic: true }))

    message.reply({
        embeds: [embed],
        components: [row]
    }).then(async(msg) => {
        const collector = msg.createMessageComponentCollector({ componentType: "SELECT_MENU", time: 600000 });

        collector.on('collect', async interaction => {
            if(interaction.user.id != message.author.id) return interaction.reply({
                content: `الزر مخصص لـ ${message.author} فقط.`,
                ephemeral: true
            })

            if(interaction.customId == "help_menu") {
                interaction.deferReply()
                await interaction.deleteReply();

                let value = interaction.values[0];

                if(value == "staff") {
                    
                    embed.setTitle("أوامر الادارة").setDescription(`
                    
\`${prefix}GMC\` 
\`${prefix}حضور-رحلة\`
\`${prefix}بدا-رحلة\`
\`${prefix}نقاطي\`
\`${prefix}تفعيل\` \`<الشخص>\` \`<اسم الحساب>\`
\`${prefix}قبول-وظايف\` \`<الشخص>\`
\`${prefix}ازالة-وظايف\` \`<الشخص>\`
                    `)

                    interaction.message.edit({
                        embeds: [embed]
                    })
                } else if(value == "public") {
                    
                    embed.setTitle("الأوامر العامة").setDescription(`

**أوامر البنك**
\`${prefix}ايداع\` \`<الكمية>\`
\`${prefix}سحب\` \`<الكمية>\`
\`${prefix}فلوسي\`
\`${prefix}تحويل\` \`<الشخص>\` \`<الكمية>\`

**أوامر الحقيبة**
\`${prefix}buy\` \`<amount>\` \`<type>\`
\`${prefix}give-item\` \`<user>\` \`<amount>\` \`<type>\`
\`${prefix}inv\`
\`${prefix}store\`
\`${prefix}use\` \`<amount>\` \`<type>\`
\`${prefix}سرقة\` \`<النوع>\`

**أوامر الهويات**
\`${prefix}انشاء-هوية\`
\`${prefix}تعديل-هوية\`
\`${prefix}هويتي\`

**أوامر الشرطة**
\`${prefix}سداد\` \`<النوع>\`
\`${prefix}سداد-الكل\`
\`${prefix}مخالفاتي\` `)

                    interaction.message.edit({
                        embeds: [embed]
                    })
                } else if(value == "mod") {
                    
                    embed.setTitle("أوامر المسؤولين").setDescription(`

**أوامر البنك**
\`${prefix}اضافة-فلوس\` \`<الشخص>\` \`<المبلغ>\`
\`${prefix}خصم-فلوس\` \`<الشخص>\` \`<المبلغ>\`

**أوامر الحقيبة**
\`${prefix}add-item\` \`<الشخص>\` \`<الكمية>\` \`<المنتج>\`
\`${prefix}add-store\` \`<المبلغ>\` \`<المنتج>\`
\`${prefix}reset-store\`
\`${prefix}reset-item\` \`<الشخص>\`
\`${prefix}delete-items\` \`<المنتج>\`
\`${prefix}delete-bag\` \`<الشخص>\` \`<المنتج>\`

**أوامر مسؤولين نقاط الادارة**
\`${prefix}اضافة-نقاط\` \`<الشخص>\` \`<عدد النقاط>\`
\`${prefix}ازالة-نقاط\` \`<الشخص>\` \`<عدد النقاط>\`
\`${prefix}تصفير-النقاط\` \`<الشخص>\`

**أوامر السجن أو البلاك ليست**
\`${prefix}مخالف\` \`<الشخص>\`
\`${prefix}فك-مخالف\` \`<الشخص>\``)

                    interaction.message.edit({
                        embeds: [embed]
                    })
                } else if(value == "set") {
                    
                    embed.setTitle("أوامر التعين").setDescription(`
                    
\`/add-tf3el-roles\` \`<action>\` \`<role>\`
\`/add-new-job\` \`<name>\` \`<role>\`
\`/add-new-mo5alfa\` \`<name>\` \`<price>\`
\`/add-new-reason\` \`<action>\` \`<time>\` \`<role>\`
\`/add-new-theft\` \`<name>\` \`<role>\` \`<time>\` \`<tools>\` \`<values>\`
\`/add\` \`<target>\`
\`/remove\` \`<target>\`
\`/auto-line-image\` \`<image>\`
\`/auto-line-channels add\` \`<channel>\`
\`/auto-line-channels remove\` \`<channel>\`
\`/delete-job\` \`<name>\`
\`/delete-mo5alfa\` \`<name>\`
\`/delete-reason\` \`<name>\`
\`/delete-theft\` \`<name>\`
\`/panel create\` \`<title>\` \`<description>\`
\`/panel edit\` \`<panel_id>\`
\`/set-points-staff\` \`<role>\`
\`/remove-tf3el-roles\` \`<action>\` \`<role>\`
\`/reset-all-mo5alfa\`
\`/reset-all-jobs\`
\`/reset-all-reasons\`
\`/reset-all-thefts\`
\`/reset-poline-join\`
\`/set-blacklist-channel\` \`<channel>\`
\`/set-blacklist-role\` \`<role>\`
\`/set-id-role\` \`<role>\`
\`/set-police-role\` \`<role>\`
\`/set-bank-chat\` \`<channel>\`
\`/set-game-channels\` \`<channel_1>\` \`<channel_2>\`
\`/set-staff role\` \`<role>\`
\`/setup-police-joins\` \`<main_channel>\` \`<second_channel>\`
\`/set-tf3el-log\` \`<channel>\`
\`/set-password-role\` \`<role>\`
                    `)

                    interaction.message.edit({
                        embeds: [embed]
                    })
                }
            }
        });

        collector.on('end', async(collected) => {
            if(collected.size <= 0) {
                message.delete()
                await msg.delete()
            }
        });
    })
  }
};
