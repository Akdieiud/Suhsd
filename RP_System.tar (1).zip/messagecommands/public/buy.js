const userBase = require('../../Models/userBase'), guildBase = require('../../Models/guildBase');
module.exports = {
  name: `buy`,
  run: async (client, message, args, Discord) => {
    let amount = args[0]
    if (!amount || isNaN(amount)) return message.reply({
      content: `**⚠️ - يجب عليك تحديد الكمية الذي تريد شراؤها**`
    })

    let type = args[1]
    if (!type) return message.reply({
      content: `**⚠️ - يجب عليك تحديد الشي الذي تريد شراؤها**`
    })

    let db = await guildBase.findOne({ guild: message.guild.id })
    if (!db) {
      db = new guildBase({ guild: message.guild.id })
      await db.save()
    }

    let indexx = db.store.findIndex(c => c.name.toLowerCase() == type.toLowerCase())
    if (indexx == -1) return message.reply({
      content: `**⚠️ - لن اتمكن من الوصول لهذا الغرض داخل المتجر**`
    })

    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setCustomId(`buy_${message.author.id}_1`)
        .setLabel("الشخصية الاولى")
        .setStyle("SECONDARY"),

      new Discord.MessageButton()
        .setCustomId(`buy_${message.author.id}_2`)
        .setLabel("الشخصية الثانية")
        .setStyle("SECONDARY")
    )

    let msg = await message.reply({
      content: `**أختر الشخصية الذي تريد الشراء اليها**`,
      components: [row]
    })

    const collector = msg.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
    collector.on('collect', async i => {
      if (i.user.id != message.author.id) return i.reply({
        content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
        ephemeral: true
      })

      if (i.customId.startsWith("buy")) {
        let data = await userBase.findOne({ guild: message.guild.id, user: message.author.id })
        if (!data) {
          data = new userBase({ guild: message.guild.id, user: message.author.id })
          await data.save()
        }

        i.customId.endsWith("1") ? data = data.c1 : data = data.c2

        if (Number(data.bank) < parseInt(Number(amount) * db.store[indexx].price) && Number(data.cash) < parseInt(Number(amount) * db.store[indexx].price)) return msg.edit({
          content: `**⚠️ - رصيد حسابك الحالي داخل الشخصية ${i.customId.endsWith("1") ? "الاولى" : "الثانية"} لا يكفي لشراء __${parseInt(amount)}__ من \`${type.toLowerCase()}\`**`,
          components: []
        })

        Number(data.bank) >= parseInt(Number(amount) * db.store[indexx].price) ? data.bank = Number(data.bank) - parseInt(Number(amount) * db.store[indexx].price) : data.cash = Number(data.cash) - parseInt(Number(amount) * db.store[indexx].price)
        let index2 = data.inv.findIndex(c => c.name.toLowerCase() == type.toLowerCase())
        if (index2 == -1) {
          data.inv.push({ name: type.toLowerCase(), count: parseInt(amount) })
        } else {
          data.inv[index2] = { name: type.toLowerCase(), count: parseInt(Number(data.inv[index2].count) + Number(amount)) }
        }

        await userBase.updateOne({ guild: message.guild.id, user: message.author.id },
          {
            $set: {
              [`${i.customId.endsWith("1") ? "c1" : "c2"}`]: data
            }
          }
        );

        let embed = new Discord.MessageEmbed()
        .setColor("YELLOW")
        .setThumbnail(message.guild.iconURL())
        .setTimestamp()
        .setAuthor({ name: "كشف حساب", iconURL: message.guild.iconURL() })
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
        .setDescription(`** ✅ - تم الشراء بنجاح 

| المنتج : \`${type.toLowerCase()}\`

| السعر : __${parseInt(Number(amount) * db.store[indexx].price)}__

| العدد : __${parseInt(amount)}__

| الشخصية : ${i.customId.endsWith("1") ? "الاولى" : "الثانية"}**`)

        msg.edit({
          content: null,
          embeds: [embed],
          components: []
        })
      } else return;
    })
  }
};
