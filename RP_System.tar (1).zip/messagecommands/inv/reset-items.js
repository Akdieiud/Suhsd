const userBase = require('../../Models/userBase')
  , guildBase = require('../../Models/guildBase')

module.exports = {
  name: `reset-item`,
  run: async (client, message, args, Discord) => {
    let datad = await guildBase.findOne({ guild: message.guild.id })
    if (!datad) {
      datad = new guildBase({ guild: message.guild.id })
      await datad.save()
    }

    if (!datad.invbank) return message.reply({ 
      content: `**⚠️ - يجب تعين رتبة مسؤولين الحقيبة والبنك قبل استخدام الامر**`
    })
    let role2 = message.guild.roles.cache.get(datad.invbank)
    if (!role2) return message.reply({ 
      content: `**⚠️ - لم اتمكن من الوصول لهذه الرتبة داخل السيرفر \`${db.invbank}\`**`
    })

    if (!message.member.roles.cache.has(role2.id)) return message.reply({ 
      content: `**⚠️ - هذا الامر مخصص لمسؤولين الحقيبة والبنك فقط**`
    })

    let user = message.mentions.users.first()
    if (!user) return message.reply({
      content: `**⚠️ - يجب تحديد الشخص الذي تريد تصفير حقيبته**`
    })

    if (user.bot) return message.reply({
      content: `**⚠️ - البوتات لا تملك حقائب**`
    })

    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setCustomId(`resetinv_${message.author.id}_1`)
        .setLabel("الشخصية الاولى")
        .setStyle("SECONDARY"),

      new Discord.MessageButton()
        .setCustomId(`resetinv_${message.author.id}_2`)
        .setLabel("الشخصية الثانية")
        .setStyle("SECONDARY")
    )

    let msg = await message.reply({
      content: `**قم بإختيار الشخصية الذي تريد تصفير حقيبتها**`,
      components: [row]
    })

    const collector = msg.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
    collector.on('collect', async i => {
      if (i.user.id != message.author.id) return i.reply({
        content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
        ephemeral: true
      })

      if (i.customId.startsWith("resetinv")) {
        let data = await userBase.findOne({ guild: message.guild.id, user: user.id })
        if (!data) {
          data = new userBase({ guild: message.guild.id, user: user.id })
          await data.save()
        }

        i.customId.endsWith("1") ? data = data.c1 : data = data.c2

        await userBase.updateOne({ guild: message.guild.id, user: user.id },
          {
            $set: {
              [`${i.customId.endsWith("1") ? "c1" : "c2"}.inv`]: []
            }
          }
        );

        await msg.edit({
          content: `:white_check_mark: - **تم تصفير الحقيبة بنجاح

العضو : ${user}

بواسطة : ${message.author}

الشخصية : ${i.customId.endsWith("1") ? "الاولى" : "الثانية"}**`,
          components: []
        })

      } else return;
    })
  }
};
