const userBase = require('../../Models/userBase')
  , guildBase = require('../../Models/guildBase')

module.exports = {
  name: `add-item`,
  run: async (client, message, args, Discord) => {
    let db = await guildBase.findOne({ guild: message.guild.id })
    if (!db) {
      db = new guildBase({ guild: message.guild.id })
      await db.save()
    }

    if (!db.invbank) return message.reply({
      content: `**⚠️ - يجب تعين رتبة مسؤولين الحقيبة والبنك قبل استخدام الامر**`
    })
    let role2 = message.guild.roles.cache.get(db.invbank)
    if (!role2) return message.reply({
      content: `**⚠️ - لم اتمكن من الوصول لهذه الرتبة داخل السيرفر \`${db.invbank}\`**`
    })

    if (!message.member.roles.cache.has(role2.id)) return message.reply({
      content: `**⚠️ - هذا الامر مخصص لمسؤولين الحقيبة والبنك فقط**`
    })

    let user = message.mentions.users.first()
    if (!user) return message.reply({
      content: `**⚠️ - يجب تحديد الشخص الذي تريد اضافه غرض له**`
    })

    let amount = args[1]
    if (!amount || isNaN(amount)) return message.reply({
      content: `**⚠️ - يجب تحديد كمية الغرض الذي تريد اضافتها له**`
    })

    let type = args[2]
    if (!type) return message.reply({
      content: `**⚠️ - يجب تحديد الغرض الذي تريد اضافته له**`
    })

    if (user.bot) return message.reply({
      content: `**⚠️ - البوتات لا تملك حقائب**`
    })

    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setCustomId(`addinv_${message.author.id}_1`)
        .setLabel("الشخصية الاولى")
        .setStyle("SECONDARY"),

      new Discord.MessageButton()
        .setCustomId(`addinv_${message.author.id}_2`)
        .setLabel("الشخصية الثانية")
        .setStyle("SECONDARY")
    )

    let msg = await message.reply({
      content: `**قم بإختيار الشخصية الذي تريد الإضافة لها**`,
      components: [row]
    })

    const collector = msg.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
    collector.on('collect', async i => {
      if (i.user.id != message.author.id) return i.reply({
        content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
        ephemeral: true
      })

      if (i.customId.startsWith("addinv")) {
        let data = await userBase.findOne({ guild: message.guild.id, user: user.id })
        if (!data) {
          data = new userBase({ guild: message.guild.id, user: user.id })
          await data.save()
        }

        i.customId.endsWith("1") ? data = data.c1 : data = data.c2

        let index = data.inv.findIndex(c => c.name.toLowerCase() == type.toLowerCase())
        if (index == -1) {
          data.inv.push({ name: type.toLowerCase(), count: parseInt(amount) })
        } else {
          data.inv[index] = { name: type.toLowerCase(), count: parseInt(Number(data.inv[index].count) + Number(amount)) }
        }

        await userBase.updateOne({ guild: message.guild.id, user: user.id },
          {
            $set: {
              [`${i.customId.endsWith("1") ? "c1" : "c2"}.inv`]: data.inv
            }
          }
        );

        let embed = new Discord.MessageEmbed()
        .setColor("YELLOW")
        .setAuthor({ name: "استعلام عن هوية", iconURL: message.author.avatarURL() })
        .setThumbnail(message.guild.iconURL())
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
        .setTimestamp()
        .setDescription(`** ✅ - تم تحويل المنتج بنجاح 

| المواطن : ${user}

| بواسطة : ${message.author}

| المنتج : \`${type.toLowerCase()}\`

| الى الشخصية : ${i.customId.endsWith("1") ? "الاولى" : "الثانية"}**`)

        await msg.edit({
            content: null,
            embeds: [embed],
            components: []
        })
      } else return;
    })
  }
};
