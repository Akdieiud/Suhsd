const guildBase = require('../../Models/guildBase')

module.exports = {
  name: `reset-store`,
  run: async (client, message, args, Discord) => {
    let datad = await guildBase.findOne({ guild: message.guild.id })
    if (!datad) {
      datad = new guildBase({ guild: message.guild.id })
      await datad.save()
    }

    if (!datad.invbank) return message.reply({ 
      content: `**⚠️ - يجب تعين رتبة مسؤولين الحقيبة والبنك قبل استخدام الامر**`
    })
    let role2 = message.guild.roles.cache.get(datad.invbank)
    if (!role2) return message.reply({ 
      content: `**⚠️ - لم اتمكن من الوصول لهذه الرتبة داخل السيرفر \`${db.invbank}\`**`
    })

    if (!message.member.roles.cache.has(role2.id)) return message.reply({ 
      content: `**⚠️ - هذا الامر مخصص لمسؤولين الحقيبة والبنك فقط**`
    })

    let data = await guildBase.findOne({ guild: message.guild.id })
    if (!data) {
      data = new guildBase({ guild: message.guild.id })
      await data.save()
    }

    data.store = []
    await data.save()

    await message.reply({
      content: `**:white_check_mark: - تم بنجاح تصفير جميع منتجات المتجر**`
    })
  }
};
