const userBase = require('../../Models/userBase')
  , guildBase = require('../../Models/guildBase')

module.exports = {
  name: `اضافة-فلوس`,
  run: async (client, message, args, Discord) => {
    let db = await guildBase.findOne({ guild: message.guild.id })
    if (!db) {
      db = new guildBase({ guild: message.guild.id })
      await db.save()
    }

    if (!db.invbank) return message.reply({ content: `**⚠️ - لم يتم تعين رتبة المسؤولين عن الحقيبة والبنك حتى الان**` })
    let role2 = message.guild.roles.cache.get(db.invbank)
    if (!role2) return message.reply({ content: `**⚠️ - لا استطيع ايجاد هذه الرول \`${db.invbank}\` داخل هذا الخادم**` })

    if (!message.member.roles.cache.has(role2.id)) return message.reply({ content: `**⚠️ - هذا الامر مخصص لمسؤولين الحقيبة والبنك فقط**` })

    let user = message.mentions.members.first()
    if (!user) return message.reply({
      content: `**⚠️ -يجب عليك تحديد الشخص الذي تريد اضافة فلوس له**`
    })

    let amount = args[1]
    if (!amount || isNaN(amount)) return message.reply({
      content: `**⚠️ - يجب عليك تحديد الكمية الذي تريد اضافتها لحسابه البنكي**`
    })

    if (user.user.bot) return message.reply({
      content: `**⚠️ - عذراً ، فالبوتات ليس لديها حساب بنكي**`
    })

    let user_roles = user.roles.cache.map(c => c.id)
      , required_roles = db.tf3el.add_role

    if ((required_roles.every(val => user_roles.includes(val.toLowerCase())) && user_roles.length >= required_roles.length) == false) return message.reply({
      content: `**⚠️ - عذرا فهذا العضو ${user} غير مُفعل وليس لديه حساب بنكي**`,
      components: []
    })

    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setCustomId(`addm_${message.author.id}_1`)
        .setLabel("الشخصية الاولى")
        .setStyle("SECONDARY"),

      new Discord.MessageButton()
        .setCustomId(`addm_${message.author.id}_2`)
        .setLabel("الشخصية الثانية")
        .setStyle("SECONDARY")
    )

    let msg = await message.reply({
      content: `**قم بإختيار الشخصية الذي تريد الإضافة لها**`,
      components: [row]
    })

    const collector = msg.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
    collector.on('collect', async i => {
      if (i.user.id != message.author.id) return i.reply({
        content: `ليس لديك صلاحيات لاستخدام هذا الاختيار`,
        ephemeral: true
      })

      if (i.customId.startsWith("addm")) {
        let data = await userBase.findOne({ guild: message.guild.id, user: user.user.id })
        if (!data) {
          data = new userBase({ guild: message.guild.id, user: user.user.id })
          await data.save()
        }

        if (!data.password) return msg.edit({
          content: `**⚠️ -لا يمكنك اضافة اموال لهذا الشخص لانه لا يملك كلمة سر**`,
          components: []
        })

        i.customId.endsWith("1") ? data = data.c1 : data = data.c2

        let total_amount = parseInt(amount)

        await userBase.updateOne({ guild: message.guild.id, user: user.user.id },
          {
            $set: {
              [`${i.customId.endsWith("1") ? "c1" : "c2"}.bank`]: parseInt(data.bank + total_amount)
            }
          }
        );

        msg.edit({
          content: `تم بنجاح إضافة **${total_amount}** لحساب ${user} البنكي داخل الشخصية ${i.customId.endsWith("1") ? "الاولى" : "الثانية"}`,
          components: []
        })
      } else return;
    })
  }
};
