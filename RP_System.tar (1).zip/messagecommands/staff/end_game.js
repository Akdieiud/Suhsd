const guildBase = require('../../Models/guildBase')

module.exports = {
  name: `انهاء`,
  aliases: ["انهاء-رحلة"],
  run: async (client, message, args, Discord) => {
    let db = await guildBase.findOne({ guild: message.guild.id })
    if (!db || !db?.channels.main_game || !db?.channels.second_game) return message.reply({
      content: `**⚠️ - يجب تعين رومات الاقيام قبل استخدام الامر**`
    })

    if (!db.staff["role"]) return message.reply({ content: `**⚠️ - يجب تعين رتبة الإدارة قبل استخدام الامر**` })
    let role2 = message.guild.roles.cache.get(db.staff["role"])
    if (!role2) return message.reply({ 
      content: `**⚠️ - لن اتمكن من الوصول لهذه الرتبة داخل السيرفر \`${db.staff["role"]}\`**`
    })

    if (!message.member.roles.cache.has(role2.id)) return message.reply({ 
      content: `**⚠️ - هذا الامر مخصص للإدارة فقط**`
    })

    let channel = message.guild.channels.cache.get(db.channels.second_game)
    if (!channel) return message.reply({
      content: `**⚠️ - لن اتمكن من الوصول لهذا الروم داخل السيرفر \`${db.channels.second_game}\`**`
    })

    channel?.send({
      content: `**
اتى إعصار الجميع يسافر ، إنتهت الرحلة شكراً لكم ولحضوركم  ~ شكرآ لجميع من حضر القيم كان قيم ممتع معاكم و الي مالحق يتعوض بالاقيام الجايه بالتوفيق للجميع
 
| من قبل : ${message.author}
      
شـاكـريـن لـكـم 
      
|| @everyone || **`
    })

    message.reply({ content: `**:white_check_mark: - تم إنهاء الرحلة بنجاح**` })
  }
};