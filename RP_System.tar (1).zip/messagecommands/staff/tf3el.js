const guildBase = require('../../Models/guildBase')
  , userBase = require('../../Models/userBase')
  , { addpoints, sleep } = require("../../functions");

module.exports = {
  name: `تفعيل`,
  run: async (client, message, args, Discord) => {
    let db = await guildBase.findOne({ guild: message.guild.id })
    if (!db) {
      db = new guildBase({ guild: message.guild.id })
      await db.save();
    }

    if (!db.staff["role"]) return message.reply({ content: `**⚠️ - يجب تعين رتبة الإدارة قبل استخدام الامر**` })
    let role2 = message.guild.roles.cache.get(db.staff["role"])
    if (!role2) return message.reply({
      content: `**⚠️ - لن اتمكن من الوصول لهذه الرتبة داخل السيرفر \`${db.staff["role"]}\`**`
    })

    if (!message.member.roles.cache.has(role2.id)) return message.reply({
      content: `**⚠️ - هذا الامر مخصص للإدارة فقط**`
    })

    if (!db.tf3el || db.tf3el["add_role"]?.length <= 0 || db.tf3el["remove_role"]?.length <= 0) return message.reply({
      content: `**⚠️ - يجب تعين رتب التفعيل قبل استخدام الامر**`
    })

    let user = message.mentions.members.first()
    if (!user) return message.reply({ content: `**⚠️ - يجب عليك ذكر الشخص الذي تريد تفعيله**` })

    let username = message.content.split(" ").slice(2).join(" ")
    if (!username) return message.reply({ content: `**⚠️ - يجب عليك ذكر اسم الحساب الذي تريد تعينه للشخص**` })

    if (user.user.bot) return message.reply({ content: `**⚠️ - لا يمكن تفعيل البوتات**` })

    let user_roles = user.roles.cache.map(c => c.id)
      , required_roles = db.tf3el.add_role

    if ((required_roles.every(val => !user_roles.includes(val.toLowerCase())) && user_roles.length >= required_roles.length) == false) return message.reply({
      content: `**⚠️ - ${user} تعذر تفعيله ، لقد تم تفعيله سابقاً من قبل**`,
      components: []
    })

    db.tf3el.add_role.forEach(async hamoudi_role => {
      let add_role = message.guild.roles.cache.get(hamoudi_role)
      if (!add_role) return;

      await user.roles.add(add_role.id).catch(() => 0)
    })
    sleep(1500)

    db.tf3el.remove_role.forEach(async hamoudi_role2 => {
      let remove_role = message.guild.roles.cache.get(hamoudi_role2)
      if (!remove_role) return;

      await user.roles.remove(remove_role.id).catch(() => 0)
    })
    sleep(1500)

    await user.setNickname(username).catch(() => 0)

    let password = Math.floor(Math.random() * 9999) + 9999

    let embed = new Discord.MessageEmbed()
      .setColor("BLUE")
      .setAuthor({ name: message.guild.name, iconURL: message.guild.iconURL() })
      .setDescription(`** <:pp721:1133323531996893214> | عزيزي المواطن : __${user}__

<:pp457:1133323428213051483> | تم تفعيلك في مدينة ${message.guild.name} .

<:m7:1134063795468243065> | من قبل الأداري :  __${message.author}__

<:iD:1125075224833032212> | رقمك السري لبطاقة صرافتك في البنك هي :  ${password}

<:m7:1134063795468243065> لتصفح اوامر البنك : ${db.channels["bank"] ? `<#${db.channels["bank"]}>` : "Unknown"}**`)

    user.send({ embeds: [embed] }).catch(() => 0)

    let eeee = new Discord.MessageEmbed()
      .setColor("YELLOW")
      .setAuthor({ name: message.guild.name, iconURL: message.guild.iconURL() })
      .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
      .setThumbnail(message.guild.iconURL())
      .setTimestamp()
      .setDescription(`** ✅ - تم تفعيل العضو بنجاح 

| العضو : ${user}

| المسؤول : ${message.author}

✔️ - تم اضافة نقطة إدارية **`)

    message.reply({ embeds: [eeee] })

    addpoints(message.guild.id, message.author.id, "tf3el", 1)

    let data = await userBase.findOne({ guild: message.guild.id, user: user.user.id })
    if (!data) {
      data = new userBase({ guild: message.guild.id, user: user.user.id })
      await data.save()
    }

    data.password = password
    await data.save();

    let ee = new Discord.MessageEmbed()
      .setColor("YELLOW")
      .setTimestamp()
      .setAuthor({ name: "تفعيل عضو", iconURL: message.guild.iconURL() })
      .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
      .setDescription(`**الاداري : ${message.author}

العضو : ${user}**`)

    let log = message.guild.channels.cache.get(db.tf3el["log"])
    if (log) {
      log?.send({ embeds: [ee] })
    }

  }
};
