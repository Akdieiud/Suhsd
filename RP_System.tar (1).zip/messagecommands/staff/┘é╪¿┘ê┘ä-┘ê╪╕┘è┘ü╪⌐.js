const guildBase = require('../../Models/guildBase')
    , { sleep } = require("../../functions");

module.exports = {
    name: `قبول-وظايف`,
    run: async (client, message, args, Discord) => {
        let db = await guildBase.findOne({ guild: message.guild.id })
        if (!db) {
            db = new guildBase({ guild: message.guild.id })
            await db.save()
        }

        if (!db.staff["role"]) return message.reply({ content: `**⚠️ - يجب تعين رتبة الإدارة قبل استخدام الامر**` })
        let role2 = message.guild.roles.cache.get(db.staff["role"])
        if (!role2) return message.reply({ 
            content: `**⚠️ - لن اتمكن من الوصول لهذه الرتبة داخل السيرفر \`${db.staff["role"]}\`**`  
        })

        if (!message.member.roles.cache.has(role2.id)) return message.reply({ 
            content: `**⚠️ - هذا الامر مخصص للإدارة فقط**`
        })

        let user = message.mentions.members.first()
        if (!user) return message.reply({
            content: `**⚠️ - يجب عليك ذكر الشخص الذي تريد اضافة وظيفه له**`
        })

        if (user.user.bot) return message.reply({ content: `**⚠️ - لا يمكن توظيف البوتات**` })

        if (db.jobs.length <= 0) return message.reply({ content: `**⚠️ - لا يوجد وظايف تمت إضافتها حتى الان**` })

        let row2 = new Discord.MessageActionRow()
            .addComponents(
                new Discord.MessageSelectMenu()
                    .setCustomId(`types_jobs`)
                    .setPlaceholder('حدد الوظيفة الذي تريد اضافتها')
                    .setMinValues(1)
                    .setMaxValues(db.jobs.length)
                    .addOptions(db.jobs.map(type => ({ label: `${type.name}`, value: `${type.name}` })))
            );

        let msg2 = await message.reply({ components: [row2] })
        const collector = msg2.createMessageComponentCollector({ componentType: 'SELECT_MENU', time: 20000 });
        collector.on('collect', async i2 => {
            if (i2.user.id != message.author.id) return i2.reply({
                content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
                ephemeral: true
            })

            let embed = new Discord.MessageEmbed()
                .setColor("YELLOW")
                .setAuthor({ name: message.guild.name, iconURL: message.guild.iconURL() })
                .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
                .setTimestamp()

            if (i2.customId.startsWith("types_jobs")) {
                let values = i2.values
                    , joobs = ""
                for (const value of values) {
                    let index = db.jobs.findIndex(c => c.name.toLowerCase() == value.toLowerCase())
                    if (index == -1) return msg2.edit({ components: [], content: `**⚠️ - لا استطيع ايجاد الوظيفة داخل الوظايف ، ربما تم حذفها**` })

                    let role = message.guild.roles.cache.get(db.jobs[index].role)
                    if (!role) return;

                    joobs += `${value}, `

                    if (!user.roles.cache.has(role.id)) {
                        sleep(2000)
                        user.roles.add(role.id).catch(() => 0)
                    }
                }

                embed.setDescription(`**__ | عزيزي العضو : ${user}

| تم قبولك في وضيفه : \`${joobs}\`

| من قبل الأداري : ${message.author}

شاكرين لك . __**`)

                await msg2.edit({ components: [], embeds: [embed] })
                await user.send({ embeds: [embed] }).catch(() => 0)
            }
        })
    }
};
