
const userBase = require("../../Models/userBase")
  , guildBase = require("../../Models/guildBase")

module.exports = {
  name: `set-password`,
  run: async (client, message, args, Discord) => {
    let datad = await guildBase.findOne({ guild: message.guild.id })
    if (!datad) {
      datad = new guildBase({ guild: message.guild.id })
      await datad.save()
    }

    if (!datad.password_admin) return message.reply({ 
      content: `**⚠️ - لم يتم تعين رتبة المسؤولين عن كلمات السر حتى الان**` 
    })
    let role2 = message.guild.roles.cache.get(datad.password_admin)
    if (!role2) return message.reply({ 
      content: `**⚠️ - لا استطيع ايجاد هذه الرول \`${datad.password_admin}\` داخل هذا الخادم**` 
    })

    if (!message.member.roles.cache.has(role2.id)) return message.reply({ 
      content: `**⚠️ - هذا الامر مخصص لمسؤولين كلمات السر فقط**` 
    })

    let user = message.mentions.users.first()
    if (!user) return message.reply({ 
      content: `**⚠️ - يجب عليك منشن العضو الذي تريد تعين كلمة سر له**` 
    })

    let password = args[1]
    if (!password) return message.reply({ 
      content: `**⚠️ - يجب عليك كتابة كلمة السر الذي تريد تعينها**` 
    })
    if (isNaN(password)) return message.reply({ 
      content: `**⚠️ - كلمة السر يجب ان تكون ارقام فقط**` 
    })

    let data = await userBase.findOne({ guild: message.guild.id, user: user.id })
    if (!data) {
      data = new userBase({ guild: message.guild.id, user: user.id })
      await data.save()
    }

    data.password = password
    await data.save()

    await message.reply({
      content: `**:white_check_mark: - تم تعين كلمة سر للعضو ${user}**`
    })
  }
};
