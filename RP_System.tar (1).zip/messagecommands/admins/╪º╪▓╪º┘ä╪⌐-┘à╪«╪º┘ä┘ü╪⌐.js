const userBase = require('../../Models/userBase')
  , guildBase = require('../../Models/guildBase')

module.exports = {
  name: `ازالة-مخالفة`,
  aliases: ["ازالة-مخالفه"],
  run: async (client, message, args, Discord) => {
    let datad = await guildBase.findOne({ guild: message.guild.id })
    if (!datad) {
      datad = new guildBase({ guild: message.guild.id })
      await datad.save()
    }

    if (!datad.police) return message.reply({ content: `**⚠️ - لم يتم تعين رتبة المسؤولين عن الشرطة حتى الان**` })

    let role = message.guild.roles.cache.get(datad.police)
    if (!role) return message.reply({ content: `**⚠️ - لا استطيع ايجاد هذه الرول \`${datad.police}\` داخل هذا الخادم**` })

    if (!message.member.roles.cache.has(role.id)) return message.reply({ content: `**⚠️ - هذا الامر متاح لمسؤولين الشرطة فقط**` })


    let user = message.mentions.users.first()
    if (!user) return message.reply({
      content: `**⚠️ - يجب عليك ذكر الشخص الذي تريد ازاله مخالفة منه**`
    })

    if (user.bot) return message.reply({ content: `**⚠️ - لا يمكنك ازالة مخالفة من هذا الشخص ${user} لانه بوت**` })

    let type = message.content.split(" ").slice(2).join(" ")
    if (!type) return message.reply({
      content: `**⚠️ - يجب عليك ذكر اسم المخالفة الذي تريد ازالتها**`
    })

    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setCustomId(`removemo5fals_${message.author.id}_1`)
        .setLabel("الشخصية الاولى")
        .setStyle("SECONDARY"),

      new Discord.MessageButton()
        .setCustomId(`removemo5fals_${message.author.id}_2`)
        .setLabel("الشخصية الثانية")
        .setStyle("SECONDARY")
    )

    let msg = await message.reply({
      content: `**قم بإختيار الشخصية الذي تريد ازالة مخالفة عنها**`,
      components: [row]
    })

    const collector = msg.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
    collector.on('collect', async i => {
      if (i.user.id != message.author.id) return i.reply({
        content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
        ephemeral: true
      })

      if (i.customId.startsWith("removemo5fals")) {
        let data = await userBase.findOne({ guild: message.guild.id, user: user.id })
        if (!data) {
          data = new userBase({ guild: message.guild.id, user: user.id })
          await data.save()
        }

        i.customId.endsWith("1") ? data = data.c1 : data = data.c2

        if (data.m5alfat.length <= 0) return msg.edit({
          content: `**⚠️ - الشخصية ${i.customId.endsWith("1") ? "الاولى" : "الثانية"} للعضو ${user} لا تملك اي مخالفات لإزالتها**`,
          components: []
        })

        let index = data.m5alfat.findIndex(c => c.type.toLowerCase() == type.toLowerCase())
        if (index == -1) return msg.edit({
          content: `**⚠️ - لا استطيع ايجاد هذه المخالفة \`${type}\` داخل مخالفات شخصية ${user} ${i.customId.endsWith("1") ? "الاولى" : "الثانية"}**`,
          components: []
        })

        data.m5alfat.splice(index, 1)
        await userBase.updateOne({ guild: message.guild.id, user: user.id },
          {
            $set: {
              [`${i.customId.endsWith("1") ? "c1" : "c2"}.m5alfat`]: data.m5alfat
            }
          }
        );

        let embed = new Discord.MessageEmbed()
        .setColor("YELLOW")
        .setThumbnail(message.guild.iconURL())
        .setTimestamp()
        .setAuthor({ name: message.guild.name, iconURL: message.guild.iconURL() })
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
        .setDescription(`**✅ - تم ازالة المخالفة بنجاح 

| المواطن : ${user}

| بواسطة : ${message.author}

| المخالفة : \`${type}\`

| سعر المخالفة : __${data.mo5alfat[index].price}__

| الشخصية : ${i.customId.endsWith("1") ? "الاولى" : "الثانية"}**`)

        msg.edit({
          content: `تم إزالة المخالفة \`${type}\` من شخصية العضو ${user} ${i.customId.endsWith("1") ? "الاولى" : "الثانية"}`,
          components: []
        })
      }
    })
  }
};
