const userBase = require('../../Models/userBase')
  , guildBase = require('../../Models/guildBase');

module.exports = {
  name: `حذف-هوية`,
  aliases: ["حذف-هويه"],
  run: async (client, message, args, Discord) => {
    let db = await guildBase.findOne({ guild: message.guild.id })
    if (!db) {
      db = new guildBase({ guild: message.guild.id })
      await db.save();
    }

    if (!db.id_role) return message.reply({ content: `**⚠️ - لم يتم تعين رتبة المسؤولين الهويات حتى الان**` })

    let role = message.guild.roles.cache.get(db.id_role)
    if (!role) return message.reply({ content: `**⚠️ - لا استطيع ايجاد هذه الرول \`${db.id_role}\` داخل هذا الخادم **` })

    if (!message.member.roles.cache.has(role.id)) return message.reply({ content: `هذا الامر متاح لمسؤولين الهوية فقط**` })

    let user = message.mentions.members.first()
    if (!user) return message.reply({
      content: `**⚠️ - يجب عليك تحديد الشخص الذي تريد اضافة مخالفه له**`
    })

    if (user.user.bot) return message.reply({ content: `**⚠️ - لا يمكنك حذف هوية هذا الشخص ${user} لانه بوت**` })

    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setCustomId(`deleteId_${message.author.id}_1`)
        .setLabel("الشخصية الاولى")
        .setStyle("SECONDARY"),

      new Discord.MessageButton()
        .setCustomId(`deleteId_${message.author.id}_2`)
        .setLabel("الشخصية الثانية")
        .setStyle("SECONDARY")
    )

    let msg = await message.reply({
      content: `**قم بإختيار الشخصية الذي تريد حذف هويتها**`,
      components: [row]
    })

    const collector = msg.createMessageComponentCollector({ componentType: 'BUTTON', time: 20000 });
    collector.on('collect', async i => {
      if (i.user.id != message.author.id) return i.reply({
        content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
        ephemeral: true
      })

      if (i.customId.startsWith("deleteId")) {
        let data = await userBase.findOne({ guild: message.guild.id, user: user.user.id })
        if (!data) {
          data = new userBase({ guild: message.guild.id, user: user.user.id })
          await data.save()
        }

        i.customId.endsWith("1") ? data = data.c1 : data = data.c2

        if (!data.id || Object.keys(data.id).length <= 0) return msg.edit({
          content: `**⚠️ - هذه الشخصية ${i.customId.endsWith("1") ? "الاولى" : "الثانية"} ليس لديها هوية لحذفها**`,
          components: []
        })

        data.id = {}
        await userBase.updateOne({ guild: message.guild.id, user: user.user.id },
          {
            $set: {
              [`${i.customId.endsWith("1") ? "c1" : "c2"}`]: data
            }
          }
        );

        msg.edit({
          content: `:white_check_mark: - تم بنجاح حذف هوية الشخصية ${i.customId.endsWith("1") ? "الاولى" : "الثانية"} للعضو ${user}`,
          components: []
        })

        let embed = new Discord.MessageEmbed()
          .setColor("YELLOW")
          .setAuthor({ name: message.guild.name, iconURL: message.guild.iconURL() })
          .setTimestamp()
          .setThumbnail(message.guild.iconURL())
          .setDescription(`**__ عزيزي المواطن : ${user}

تم حذف هويتك الوطنية من قبل وزارة الداخلية
        
شاكرين لك ✅ __**`)

        await user.send({ embeds: [embed] }).catch(() => 0)
      } else return;
    })
  }
};
