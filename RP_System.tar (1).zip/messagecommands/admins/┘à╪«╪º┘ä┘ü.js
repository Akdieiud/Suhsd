const guildBase = require('../../Models/guildBase')
  , Blacklisted = require('../../Models/blacklisted')
  , pretty = require("pretty-ms")
  , { sleep } = require("../../functions");

module.exports = {
  name: `مخالف`,
  run: async (client, message, args, Discord) => {
    let db = await guildBase.findOne({ guild: message.guild.id })
    if (!db) {
      db = new guildBase({ guild: message.guild.id })
      await db.save()
    }

    if (!db.blacklist) return message.reply({ content: `**⚠️ - لم يتم تعين رتبة المسؤولين عن البلاك ليست حتى الان**` })

    let role = message.guild.roles.cache.get(db.blacklist)
    if (!role) return message.reply({ content: `**⚠️ - لا استطيع ايجاد هذه الرول \`${db.poblacklistlice}\` داخل هذا الخادم **` })

    if (!message.member.roles.cache.has(role.id)) return message.reply({ content: `هذا الامر متاح لمسؤولين بلاك ليست فقط**` })

    let user = message.mentions.members.first()
    if (!user) return message.reply({
      content: `**⚠️ - يجب عليك تحديد الشخص الذي تريد معاقبته**`
    })

    if (user.user.bot) return message.reply({ content: `**⚠️ - لا يمكنك معاقبة هذا الشخص ${user} لانه بوت**` })
    if (db.reasons.length <= 0) return message.reply({ content: `**⚠️ - لا يوجد عقوبات تمت إضافتها حتى الان**` })

    let blacklist_data = await Blacklisted.findOne({ guild: message.guild.id, user: user.user.id })
    if (blacklist_data) return message.reply({ content: `**⚠️ - لا يمكنك معاقبة ${user} لانه مُعاقب بالفعل**` })

    let row = new Discord.MessageActionRow()
      .addComponents(
        new Discord.MessageSelectMenu()
          .setCustomId(`blacklist_reasons`)
          .setPlaceholder('حدد العقوبة!')
          .setMinValues(1)
          .setMaxValues(db.reasons.length)
          .addOptions(db.reasons.map(type => ({ label: `${type.name}`, value: `${type.name}`, description: `Time: ${pretty(type.time)}` })))
      );

    let msg2 = await message.reply({ components: [row] })
    const collector = msg2.createMessageComponentCollector({ componentType: 'SELECT_MENU', time: 20000 });
    collector.on('collect', async i2 => {
      if (i2.user.id != message.author.id) return i2.reply({
        content: `**⚠️ - ليس لديك صلاحيات لاستخدام هذا الاختيار**`,
        ephemeral: true
      })

      if (i2.customId.startsWith("blacklist_reasons")) {
        let values = i2.values, total_time = 0;
        const user_roles = user.roles.cache.filter(role => role.name != "@everyone").map(role => role.id);
        const blacklisted_roles = [];

        for (var value of values) {
          let index = db.reasons.findIndex(c => c.name.toLowerCase() == value.toLowerCase())
          if (index == -1) return;

          let reason_data = db.reasons[index];

          total_time += reason_data?.time
          sleep(1000)

          user.roles.add(reason_data?.role)
          blacklisted_roles.push(reason_data?.role)
        }
        sleep(3000)

        new Blacklisted({
          guild: message.guild.id,
          user: user.user.id,
          roles: user_roles,
          time: total_time + Date.now(),
          blacklisted_roles: blacklisted_roles
        }).save();

        user_roles.forEach(role => {
          sleep(1000)
          user.roles.remove(role).catch(() => 0)
        })
        sleep(2000)

        let eheh = new Discord.MessageEmbed()
        .setColor("YELLOW")
        .setThumbnail(message.guild.iconURL())
        .setTimestamp()
        .setAuthor({ name: message.guild.name, iconURL: message.guild.iconURL() })
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
        .setDescription(`** ⚠️ - تم مخالفة العضو : ${user}

| بواسطة : ${message.author}

| مدة المخالفة :  \`${pretty(total_time)}\`


يجب ارفق دليل واضح للمخالفة بعد مخالفة الشخص**`)

        await msg2.edit({ components: [], content: null, embeds: [eheh] })

        let log_channel = message.guild.channels.cache.get(db.blacklist_channel)
        if (log_channel) {
          let embed = new Discord.MessageEmbed()
            .setColor("YELLOW")
            .setAuthor({ name: "مخالفة جديدة", iconURL: message.guild.iconURL() })
            .setThumbnail(message.guild.iconURL())
            .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
            .setTimestamp()
            .setDescription(`**الإداري المسوول عن السجن : ${message.author}** 

**العضو المخالف : ** ${user}
                    
**مدة العقوبة : \`${pretty(total_time)}\` **`)

          await log_channel?.send({ embeds: [embed] })
        }

        setTimeout(async function () {
          user.roles.cache.filter(role => role.name != "@everyone").map(role => role.id).forEach(role => {
            sleep(1000)
            user.roles.remove(role).catch(() => 0)
          })
          sleep(3000)
          user_roles.forEach(role => {
            sleep(1000)
            user.roles.add(role).catch(() => 0)
          })

          await Blacklisted.deleteMany({ guild: message.guild.id, user: user.user.id })
        }, total_time)
      }
    })
  }
};
